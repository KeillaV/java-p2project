package modelo.atributos.estaticos;

import modelo.Usuario;

public class AtributosProjeto {

	public static Usuario USUARIO_LOGADO;
	
}
